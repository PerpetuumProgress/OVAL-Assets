## Slow lead vehicle Scenario

- Track: Country Road with an opposite direction lane
- Ego: Driving in its own lane with above 100km/h
- Traffic: A slow traffic in the Ego's lane, makes Ego to brake hard


![](https://github.com/PerpetuumProgress/OVAL-Assets/blob/dev/algorithms/esmini/scenarios/Examples/Straight_Road_500m.PNG)


<img src="https://github.com/PerpetuumProgress/OVAL-Assets/blob/dev/algorithms/esmini/scenarios/Examples/slow-lead-vehicle.gif" width="1000" height="500"/>
